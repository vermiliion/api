from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-noobz-member'))
async def create_noobz(event):
    async def create_noobz_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text


        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**password:**')
            Quota = (await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text



        await process_user_balance_ssh(event, user_id)
        cmd = f'printf "%s\n" "{user}" "{Quota}" "30" "2" | addnoobz'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(30))
        

        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Noobzvpn Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user}`
**» Password:** `{Quota}`
**» limit ip:** `2`
**» Harga akun:** `RP.13.000`
**» Sisa saldo:** `RP.{get_saldo_from_db(user_id)}` 
**◇━━━━━━━━━━━━━━━━━◇**
**» PORT     :** `80`
**» PORT    :** `443`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Akun User:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
        """

        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_noobz_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############


# TRIAL NOOBZVPNS
@bot.on(events.CallbackQuery(data=b'trial-noobz'))
async def trial_noobz(event):
    user_id = str(event.sender_id)
    async def trial_noobz_(event):
        user = "trialX" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        ip = "1"

    # Database connection
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            has_trial INTEGER DEFAULT 0,
            last_trial_date TEXT
        )
    ''')
    conn.commit()

    # Function to check if user can trial again today
    async def can_user_trial_again(user_id):
        cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        today = DT.date.today().isoformat()

        if result is None:
            # If user does not exist in the database, add them
            cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
            conn.commit()
            return True  # User has never trialed, allow trial

        last_trial_date = result[0]

        if last_trial_date is None or last_trial_date != today:
            # If user hasn't trialed today, allow trial
            return True

        # User has already trialed today
        return False

    # Function to mark today's trial date
    async def mark_user_trial_today(user_id):
        today = DT.date.today().isoformat()
        cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
        conn.commit()

    async def trial_noobz_(event):

        # Loading animation
        for dots in range(1, 5):
            await event.edit(f"Processing{'.' * dots}")
            await asyncio.sleep(0.5)

        await event.edit("`Processing Create Premium Account`")
        await asyncio.sleep(1)

        # Output command (ensure DOMAIN is defined elsewhere)
        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | addnoobz'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
** ⟨🔸Trial Noobzvpn Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit IP:** `{ip}`
**◇━━━━━━━━━━━━━━━━━◇**
**» PORT     :** `80`
**» PORT    :** `443`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
```GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Akun User:** `{today}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
        """
        await event.respond(msg)

    try:
        if await can_user_trial_again(user_id):
            await trial_noobz_(event)
            await mark_user_trial_today(user_id)  # Mark the trial as used for today
        else:
            await event.answer("Anda sudah menggunakan trial hari ini.", alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")
    finally:
        # Close the database connection after the function is done
        conn.close()



@bot.on(events.CallbackQuery(data=b'cek-noobz-member'))
async def cek_vmess(event):
    async def cek_noobz_(event):
        cmd = 'cek-noobz'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Noobz Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Users noobzvpns in databases**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "noobzvpns-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_noobz_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



##########











@bot.on(events.CallbackQuery(data=b'renew-noobz-member'))
async def ren_vmess(event):
    async def ren_noobz_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**PERHATIAN!! renew akun akan memotong saldo kalian sesuai harga create account**')
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text


            

        await process_user_balance_ssh(event, user_id)   
        cmd = f'noobzvpns --renew-user {user} --expired-user {user} 30'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = f"""**Successfully Renewed  {user} 30 Days price IDR.10.000**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_noobz_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

		


















@bot.on(events.CallbackQuery(data=b'noobzvpn-member'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" 𝚃𝚁𝙸𝙰𝙻 𝙽𝙾𝙾𝙱𝚉𝚅𝙿𝙽𝚂 ", "trial-noobz-member"),
             Button.inline(" 𝙲𝚁𝙴𝙰𝚃𝙴 𝙽𝙾𝙾𝙱𝚉𝚅𝙿𝙽 ", "create-noobz-member")],
            [Button.inline(" 𝚁𝙴𝙽𝙴𝚆 𝙽𝙾𝙾𝙱𝚉𝚅𝙿𝙽𝚂 ", "renew-noobz-member")],

            [Button.inline(" 𝙲𝙷𝙴𝙲𝙺 𝙼𝙴𝙼𝙱𝙴𝚁 𝙽𝙾𝙾𝙱𝚉𝚅𝙿𝙽𝚂 ", "cek-noobz-member")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸NOOBZVPNS SERVICE🔸⟩◇**
             **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `NOOBZVPNS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


