from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    last_trial_date = result[0]
    
    if last_trial_date is None or last_trial_date != today:
        # Jika user belum trial hari ini, izinkan trial
        return True
    
    # Jika user sudah trial hari ini
    return False

# Fungsi untuk mencatat tanggal trial terakhir
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
    conn.commit()

# Simulasi fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        
        # Perintah untuk menambahkan user baru
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            msg = f"""
◇━━━━━━━━━━━━━━━━━◇
** ⟨🔸𝚃𝚛𝚒𝚊𝚕 𝚂𝚂𝙷 𝙰𝚌𝚌𝚘𝚞𝚗𝚝🔸⟩**
◇━━━━━━━━━━━━━━━━━◇
» 𝙳𝚘𝚖𝚊𝚒𝚗: `{DOMAIN}`
» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎: `{user.strip()}`
» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍: `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
» 𝙿𝚘𝚛𝚝 𝙾𝚙𝚎𝚗𝚂𝚂𝙷 : 443, 80, 22
» 𝙿𝚘𝚛𝚝 𝙳𝚛𝚘𝚙𝚋𝚎𝚊𝚛𝚍 : 443, 109
» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙷 𝚆𝚂 : 80, 8080, 8081-9999 
» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙷 𝚄𝙳𝙿 : 1-65535 
» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙷 𝚂𝚂𝙻 𝚆𝚂 : 443
» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙻/𝚃𝙻𝚂 : 400-900
» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽 𝚆𝚂 𝚂𝚂𝙻 : 443
» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙻/𝚃𝙻𝚂 : 400-900
» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽 𝚆𝚂 𝚂𝚂𝙻 : 443
» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽 𝚃𝙲𝙿 : 443, 1194
» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽 𝚄𝙳𝙿 : 2200
» 𝙱𝚊𝚍𝚅𝙿𝙽 𝚄𝙳𝙿 : 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨𝙵𝚘𝚛𝚖𝚊𝚝 𝙷𝚃𝚃𝙿 𝙲𝚄𝚂𝚃𝙾𝙼⟩**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨𝙻𝚒𝚗𝚔 𝚂𝚊𝚟𝚎 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 & 𝙾𝚟𝚙𝚗⟩**
https://{DOMAIN}:81/ssh-{user.strip()}.txt
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨𝙿𝚊𝚢𝚕𝚘𝚊𝚍 𝚆𝚎𝚋𝚜𝚘𝚌𝚔𝚎𝚝⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕: {today}
◇━━━━━━━━━━━━━━━━━◇
**»** 🤖@Lite_Vermilion
"""
            inline = [
                [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "t.me/Lite_Vermilion"),
                 Button.url("𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙", "wa.me/6281934335091")]
            ]
            await event.respond(msg, buttons=inline)
    
    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Jika pengguna adalah user biasa, cek apakah mereka sudah trial hari ini
        if can_user_trial_again(user_id):
            await trial_ssh_(event)
            # Tandai bahwa pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
        else:
            await event.answer(f"Anda sudah melakukan trial hari ini. Silakan coba lagi besok.", alert=True)
    
    elif level == 'admin':
        # Jika admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_ssh_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)
