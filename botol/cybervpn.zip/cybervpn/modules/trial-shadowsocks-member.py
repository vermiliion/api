from cybervpn import *
import sqlite3
from telethon import events, Button
import subprocess
import datetime as DT
import random
import time
import re
import json
import base64

# Koneksi ke database SQLite
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    last_trial_date = result[0]
    
    if last_trial_date is None or last_trial_date != today:
        # Jika user belum trial hari ini, izinkan trial
        return True
    
    # Jika user sudah trial hari ini
    return False

# Fungsi untuk mencatat tanggal trial terakhir
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
    conn.commit()

# Simulasi fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks-member'))
async def trial_shadowsocks(event):
    user_id = str(event.sender_id)

    async def trial_shadowsocks_(event):
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        for i in range(5):
            await event.edit(f"`Processing... {i * 25}%\n{'' * (i + 1)}{'' * (4 - i)} `")
            time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        try:
            cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" | bot-trialss'
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            await event.respond(f"Error executing command: {e.output.decode('utf-8')}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)
        x = [x.group() for x in re.finditer("ss://(.*)", a)]

        if len(x) < 3:
            await event.respond("Error: Not enough SS URLs generated.")
            return
        
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
****
**Trial Shadowsocks Account**
****
**� Host Server :** `{DOMAIN}`
**� Port TLS    :** `443, 400-900`
**� Port NTLS   :** `80, 8080, 8081-9999 `
**� UUID    :** `{uuid}`
**� NetWork     :** `(WS) or (gRPC)`
**� Path        :** `/ss-ws`
**� ServiceName :** `ss-grpc`
****
**� URL TLS    :**
```{x[0]}```
****
**� URL HTTP   :** 
```{x[1].replace(" ","")}```
****
**� URL gRPC   :** 
```{x[2].replace(" ","")}```
****
**� Expired Until:** `{today}`
****
**� ** @Lite_Vermilion
"""
        await event.respond(msg)

    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Jika pengguna adalah user biasa, cek apakah mereka sudah trial hari ini
        if can_user_trial_again(user_id):
            await trial_shadowsocks_(event)
            # Tandai bahwa pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
        else:
            await event.answer(f"Anda sudah melakukan trial hari ini. Silakan coba lagi besok.", alert=True)
    
    elif level == 'admin':
        # Jika admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_shadowsocks_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)
