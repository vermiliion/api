from cybervpn import *
import sqlite3
from telethon import events, Button
import subprocess
import datetime as DT
import random
import time
import re
import json
import base64

# Koneksi ke database SQLite
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    last_trial_date = result[0]
    
    if last_trial_date is None or last_trial_date != today:
        # Jika user belum trial hari ini, izinkan trial
        return True
    
    # Jika user sudah trial hari ini
    return False

# Fungsi untuk mencatat tanggal trial terakhir
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
    conn.commit()

# Simulasi fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-vless-member'))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialvless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            # domain = re.search("@(.*?):", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            # path = re.search("path=(.*)&", x[0]).group(1)
            msg = f"""
****
    **Trial Vless Account**
****
**� Host Server :** `{DOMAIN}`
**� Port TLS    :** `443, 400-900`
**� Port NTLS   :** `80, 8080, 8081-9999 `
**� UUID    :** `{uuid}`
**� NetWork     :** `(WS) or (gRPC)`
**� Path        :** `/vless`
**� ServiceName :** `vless-grpc`
****
**� URL TLS    :**
```{x[0]}```
****
**� URL HTTP    :**
```{x[1].(" ","")}```
****
**� URL gRPC   :** 
```{x[2].(" ","")}```
****
**� Expired Until:** `{today}`
****
**� ** @Lite_Vermilion
"""
            
        await event.respond(msg)

    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Jika pengguna adalah user biasa, cek apakah mereka sudah trial hari ini
        if can_user_trial_again(user_id):
            await trial_vless_(event)
            # Tandai bahwa pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
        else:
            await event.answer(f"Anda sudah melakukan trial hari ini. Silakan coba lagi besok.", alert=True)
    
    elif level == 'admin':
        # Jika admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_vless_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)
