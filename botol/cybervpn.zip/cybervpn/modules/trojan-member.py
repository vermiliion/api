from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-trojan-member'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [
                 Button.inline(" 30 Day ", "30")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        # jumlah ip
        async with bot.conversation(chat) as ip:
            await event.respond("**Choose ip limit**", buttons=[
                [
                 Button.inline(" 2 IP ", "2")]
            ])
            ip = ip.wait_event(events.CallbackQuery)
            ip = (await ip).data.decode("ascii")
        
        await process_user_balance_trojan(event, user_id)

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        print(b)
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
       **⟨🔸Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443`
**» Port NTLS   :** `80`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{𝚋[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{𝚋[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{𝚋[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
"""
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'cek-tr-member'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'cek-tr'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Trojan**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')


@bot.on(events.CallbackQuery(data=b'trial-trojan-member'))
async def trial_trojan(event):
    user_id = str(event.sender_id)
    pw = "1"
    exp = "1"
    ip = "1"

    # Database connection
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            has_trial INTEGER DEFAULT 0,
            last_trial_date TEXT
        )
    ''')
    conn.commit()

    # Function to check if user can trial again today
    async def can_user_trial_again(user_id):
        cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        today = DT.date.today().isoformat()

        if result is None:
            # If user does not exist in the database, add them
            cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
            conn.commit()
            return True  # User has never trialed, allow trial

        last_trial_date = result[0]

        if last_trial_date is None or last_trial_date != today:
            # If user hasn't trialed today, allow trial
            return True

        # User has already trialed today
        return False

    # Function to mark today's trial date
    async def mark_user_trial_today(user_id):
        today = DT.date.today().isoformat()
        cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
        conn.commit()

    async def trial_trojan_(event):
        # Loading animation
        for dots in range(1, 5):
            await event.edit(f"Processing{'.' * dots}")
            await asyncio.sleep(0.5)

        await event.edit("`Processing Create Premium Account`")
        await asyncio.sleep(1)

        # Output command (ensure exp and DOMAIN are defined elsewhere)
        cmd = f'printf "%s\n" "Trial$(</dev/urandom tr -dc X-Z0-9 | head -c4)" "1" "1" "1" | bot-trialtr'

        try:
            # Capture output safely
            a = subprocess.check_output(cmd, shell=True, text=True).strip()
        except subprocess.CalledProcessError as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))  # Ensure 'exp' is defined

        # Extract trojan links using regex
        b = [x.group() for x in re.finditer(r"trojan://(.*)", a)]
        if not b or len(b) < 3:
            await event.respond("Error: Could not generate trojan links correctly.")
            return

        # Parsing values from the trojan links
        domain = re.search(r"@(.*?):", b[0]).group(1)
        uuid = re.search(r"trojan://(.*?)@", b[0]).group(1)

        # Constructing the message to send
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
  **⟨🔸Trial Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443`
**» Port NTLS   :** `80`
**» UUID        :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan`
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{b[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].replace(" ", "")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{b[2].replace(" ", "")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
        """
        await event.respond(msg)

    try:
        if await can_user_trial_again(user_id):
            await trial_trojan_(event)
            await mark_user_trial_today(user_id)  # Mark the trial as used for today
        else:
            await event.answer("Anda sudah menggunakan trial hari ini.", alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")
    finally:
        # Close the database connection after the function is done
        conn.close()

@bot.on(events.CallbackQuery(data=b'renew-trojan-member'))
async def ren_trojan(event):
    async def ren_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Perhatian! renew akun akan mengenakan biaya sesuai create account')
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        async with bot.conversation(chat) as ip:
            await event.respond("**Choose ip limit**", buttons=[
                [Button.inline(" 2 ip ", "2")]
            ])
            ip = ip.wait_event(events.CallbackQuery)
            ip = (await ip).data.decode("ascii")

        await process_user_balance_trojan(event, user_id)
        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | bot-renew-tro'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = f"""**Successfully Renewed {user} {exp} days limit ip {ip} limit Quota 100GB**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')



# CEK member tr
@bot.on(events.CallbackQuery(data=b'cek-membertr-member'))
async def cek_tr(event):
    async def cek_tr_(event):
        cmd = 'bash cek-mts'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_tr_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


		
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Successfully Renew Or Delete User**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan-member'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("𝚃𝚛𝚒𝚊𝚕 𝚃𝚛𝚘𝚓𝚊𝚗", "trial-trojan-member"),
             Button.inline("𝙲𝚛𝚎𝚊𝚝𝚎 𝚃𝚛𝚘𝚓𝚊𝚗", "create-trojan-member")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙻𝚘𝚐𝚒𝚗 𝚃𝚛𝚘𝚓𝚊𝚗", "cek-tr-member"),
             Button.inline("𝚁𝚎𝚗𝚎𝚠 𝚃𝚛𝚘𝚓𝚊𝚗", "renew-trojan-member")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙼𝚎𝚖𝚋𝚎𝚛", "cek-membertr-member")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
  **◇⟨🔸TROJAN SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@Lite_Vermilion
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trojan_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

