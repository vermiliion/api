import sqlite3
import logging
from cybervpn import *
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# Database setup
def setup_db():
    conn = sqlite3.connect('trial_users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            unlimited_trial INTEGER DEFAULT 0
        )
    ''')
    conn.commit()
    return conn, cursor

# Add user to unlimited trial
def add_trial(user_id, cursor, conn):
    cursor.execute('''
        INSERT INTO users (user_id, unlimited_trial)
        VALUES (?, ?)
        ON CONFLICT(user_id) DO UPDATE SET unlimited_trial = 1
    ''', (user_id,))
    conn.commit()

# Remove user from unlimited trial
def remove_trial(user_id, cursor, conn):
    cursor.execute('''
        UPDATE users SET unlimited_trial = 0 WHERE user_id = ?
    ''', (user_id,))
    conn.commit()

# Check if user has unlimited trial
def check_trial(user_id, cursor):
    cursor.execute('SELECT unlimited_trial FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    return result and result[0] == 1

# Command: Add user to trial
async def add_trial_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /add_trial <user_id>")
        return

    user_id = context.args[0]

    # Only admins can add trials
    if update.effective_user.id not in context.bot_data.get('admins', []):
        await update.message.reply_text("You don't have permission to do this.")
        return

    conn, cursor = setup_db()
    add_trial(user_id, cursor, conn)
    await update.message.reply_text(f"User {user_id} has been granted unlimited trial access.")

# Command: Remove user from trial
async def remove_trial_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /remove_trial <user_id>")
        return

    user_id = context.args[0]

    # Only admins can remove trials
    if update.effective_user.id not in context.bot_data.get('admins', []):
        await update.message.reply_text("You don't have permission to do this.")
        return

    conn, cursor = setup_db()
    remove_trial(user_id, cursor, conn)
    await update.message.reply_text(f"User {user_id} has been removed from unlimited trial access.")

# Command: Check if user has trial
async def check_trial_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /check_trial <user_id>")
        return

    user_id = context.args[0]
    conn, cursor = setup_db()

    if check_trial(user_id, cursor):
        await update.message.reply_text(f"User {user_id} has unlimited trial access.")
    else:
        await update.message.reply_text(f"User {user_id} does not have unlimited trial access.")

# Command: Set bot admins
async def set_admins_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /set_admins <admin_id> [admin_id ...]")
        return

    admin_ids = [int(admin_id) for admin_id in context.args]
    context.bot_data['admins'] = admin_ids
    await update.message.reply_text(f"Admins set: {', '.join(context.args)}")

# Logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Welcome! Use /add_trial <user_id>, /remove_trial <user_id>, or /check_trial <user_id>.")

if __name__ == '__main__':
    # Create bot application
    application = ApplicationBuilder().token("YOUR_BOT_TOKEN_HERE").build()

    # Register command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("add_trial", add_trial_command))
    application.add_handler(CommandHandler("remove_trial", remove_trial_command))
    application.add_handler(CommandHandler("check_trial", check_trial_command))
    application.add_handler(CommandHandler("set_admins", set_admins_command))

    # Run the bot
    application.run_polling()
