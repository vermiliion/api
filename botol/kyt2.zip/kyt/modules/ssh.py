from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.ssh-menu|/ssh-menu)$"))
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
            [Button.inline("𝚃𝚛𝚒𝚊𝚕 𝚂𝚂𝙷", "trial-ssh"),
             Button.inline("𝙲𝚛𝚎𝚊𝚝𝚎 𝚂𝚂𝙷", "create-ssh"),
             Button.inline("𝙳𝚎𝚕𝚎𝚝𝚎 𝚂𝚂𝙷", "delete-ssh")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙻𝚘𝚐𝚒𝚗 𝚂𝚂𝙷", "login-ssh")],
            [Button.inline("𝚂𝚑𝚘𝚠 𝙰𝚕𝚕 𝚄𝚜𝚎𝚛 𝚂𝚂𝙷", "show-ssh")],
[Button.inline("𝚁𝚎𝚗𝚎𝚠 𝚂𝚂𝙷", "renew-ssh")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━◇**
            **🔸SSH & OVPN🔸**
**◇━━━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH OVPN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
🤖 **» @LITE_VERMILION**
**◇━━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
