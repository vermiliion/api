from kyt import *


@bot.on(events.CallbackQuery(data=b'cek-tr'))
async def cek_trojan(event):
    try:
        # Menjalankan perintah cek-tr
        cmd = 'cek-tr'.strip()  # Pastikan 'cek-tr' ada di PATH atau gunakan path lengkap
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Menampilkan hasil ke pengguna
        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ⟨🔸Cek Trojan User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**

{result}

**Shows Logged In Users Trojan**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", b"menu")]])

    except subprocess.CalledProcessError as e:
        # Menangani error saat eksekusi perintah cek-tr
        await event.edit(f"Error: {str(e)}", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", b"menu")]])

    except Exception as e:
        # Menangani error umum lainnya
        await event.edit(f"Unexpected Error: {str(e)}", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", b"menu")]])


@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2" "1" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
  **⟨🔸Trial Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{𝚋[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{𝚋[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{𝚋[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `1 Hari`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
        

@bot.on(events.CallbackQuery(data=b'trial-bujang'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "2" "2" "2" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
  **⟨🔸Trial Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{𝚋[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{𝚋[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{𝚋[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `2 Hari`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Lite_Vermilion
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



# CEK member tr
@bot.on(events.CallbackQuery(data=b'cek-membertr'))
async def cek_tr(event):
    try:
        # Menjalankan perintah bash
        cmd = 'bash cek-mts'.strip()
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Mengirim hasil ke pengguna
        await event.edit(f"""
{result}

**Shows Users from databases**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", b"menu")]])

    except subprocess.CalledProcessError as e:
        # Jika terjadi error saat eksekusi perintah bash
        await event.edit(f"Error: {str(e)}", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", b"menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_tr_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("1 𝙷𝚊𝚛𝚒", "trial-trojan"),
             Button.inline("2 𝙷𝚊𝚛𝚒", "trial-bujang")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝚄𝚜𝚎𝚛 𝙻𝚘𝚐𝚒𝚗", "cek-tr")],
            [Button.inline("𝙻𝚒𝚜𝚝 𝚄𝚜𝚎𝚛", "cek-membertr")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸TROJAN SERVICE🔸⟩◇**             
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@Lite_Vermilion
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)